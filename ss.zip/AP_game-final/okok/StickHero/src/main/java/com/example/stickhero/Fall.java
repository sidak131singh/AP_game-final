package com.example.stickhero;

public class Fall {
    private Hero hero;
    private Stick stick;
private Poll poll;

   public void fall(){
       System.out.println(" hi ");
       System.out.println(" hello ");
       System.out.println("KMN");
   }




}

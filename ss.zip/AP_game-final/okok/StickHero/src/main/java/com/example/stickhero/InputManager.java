package com.example.stickhero;

public class InputManager {
    private Stick s;

    public void handleKeyPress(String key,Stick s) {
        // Handle key press events
    }


}
package com.example.stickhero;

public class Score {
    private int count;
    public void updateScore(int s){}
    public void Compare(int s){}


}

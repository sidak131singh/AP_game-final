package com.example.stickhero;

import javafx.stage.Stage;

import java.io.IOException;

public interface Screen {
    public Stage display() throws IOException;

}

package com.example.stickhero;

public class cherry extends coordinates {
    private int count;
    private int x_coord;
    private int y_coord;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getX_coord() {
        return x_coord;
    }

    public void setX_coord(int x_Coord) {
        this.x_coord = x_Coord;
    }

    @Override
    public int getY_coord() {
        return y_coord;
    }

    @Override
    public void setY_coord(int y_coord) {
        this.y_coord = y_coord;

    }


    public void updateCount(){

    }
    public void generateCherry(){

    }
}

package com.example.stickhero;

public abstract class coordinates {
    private int x_coord;
    private int y_coord;

    public abstract int getX_coord() ;



    public abstract void setX_coord(int x_coord) ;


    public abstract int getY_coord();


    public abstract void setY_coord(int y_coord) ;

}

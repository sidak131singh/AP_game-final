package com.example.stickhero;

public class testing {
    public static void main(String[] args) {
        System.out.println("hi");
    }
}
